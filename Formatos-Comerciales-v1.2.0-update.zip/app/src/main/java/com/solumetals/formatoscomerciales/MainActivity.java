package com.solumetals.formatoscomerciales;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import androidx.core.content.FileProvider;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    final int TEAL=Color.rgb(0,168,150), NAVY=Color.rgb(11,23,32), PALE=Color.rgb(239,248,247);
    android.content.SharedPreferences prefs; LinearLayout root, form; ScrollView scroll;
    ImageView logo; Uri logoUri; String currentType=""; EditText focused; int textColor=Color.DKGRAY; float textSize=16; int fontStyle=Typeface.NORMAL;
    final ArrayList<EditText> quantities=new ArrayList<>(), prices=new ArrayList<>(), amounts=new ArrayList<>();
    EditText subtotalField,discountField,taxField,totalField;
    int selectedTemplate=0;
    final String[] TYPES={"Recibo","Factura","Cotización","Membrete","Notas","Tarjeta de presentación"};
    final String[] TEMPLATE_NAMES={"Corporativo","Minimalista","Ejecutivo","Creativo","Elegante","Técnico"};
    final int[] TEMPLATE_COLORS={Color.rgb(19,51,75),Color.rgb(0,150,136),Color.rgb(34,42,57),Color.rgb(232,72,111),Color.rgb(119,92,153),Color.rgb(30,119,180)};

    @Override public void onCreate(Bundle b){
        super.onCreate(b); prefs=getSharedPreferences("formatos",MODE_PRIVATE);
        if(Build.VERSION.SDK_INT<29 && checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)!=getPackageManager().PERMISSION_GRANTED)
            requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE},44);
        showHome();
    }
    TextView text(String s,int sp,int color){ TextView v=new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(color); v.setPadding(12,12,12,12); return v; }
    GradientDrawable box(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);return g;}
    GradientDrawable bordered(int color,int stroke,float radius){GradientDrawable g=box(color,radius);g.setStroke(2,stroke);return g;}
    Button button(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setBackground(box(TEAL,22)); b.setAllCaps(false); b.setPadding(16,14,16,14); b.setElevation(3); return b; }
    LinearLayout base(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(24,24,24,24); l.setBackgroundColor(PALE); return l; }
    void addSpace(int h){ Space s=new Space(this); root.addView(s,new LinearLayout.LayoutParams(1,h)); }

    void showHome(){
        root=base(); scroll=new ScrollView(this); scroll.addView(root); setContentView(scroll);
        TextView title=text("FORMATOS\nCOMERCIALES",30,Color.WHITE); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setGravity(Gravity.CENTER); title.setBackground(box(NAVY,30)); title.setPadding(20,38,20,38); root.addView(title);
        TextView sub=text("Tu papelería profesional, lista para crear",16,Color.DKGRAY); sub.setGravity(Gravity.CENTER); root.addView(sub); addSpace(18);
        Button profile=button("⚙  Configurar mi negocio y logo"); root.addView(profile); profile.setOnClickListener(v->showProfile()); addSpace(20);
        String[] icons={"▣  ","▤  ","◇  ","▱  ","✎  ","▰  "};int ix=0;
        for(String t:TYPES){ Button b=button(icons[ix++]+t);b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);b.setTextColor(NAVY);b.setBackground(bordered(Color.WHITE,Color.rgb(210,224,228),24)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,120); p.setMargins(0,8,0,8); root.addView(b,p); b.setTextSize(18); b.setOnClickListener(v->showTemplates(t)); }
        TextView foot=text("Los documentos se guardan en Descargas/Papeleria",13,Color.GRAY); foot.setGravity(Gravity.CENTER); root.addView(foot);
    }

    void showTemplates(String type){
        root=base();scroll=new ScrollView(this);scroll.addView(root);setContentView(scroll);Button back=button("‹ Volver");root.addView(back);back.setOnClickListener(v->showHome());
        TextView h=text("Elige un diseño",28,NAVY);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);root.addView(h);root.addView(text("Vista previa de "+type+" · podrás cambiarla después",15,Color.DKGRAY));
        for(int i=0;i<TEMPLATE_NAMES.length;i++){final int pick=i;LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(16,16,16,16);card.setBackground(bordered(Color.WHITE,Color.rgb(210,222,228),24));TemplatePreview preview=new TemplatePreview(this,i,type);card.addView(preview,new LinearLayout.LayoutParams(190,250));LinearLayout words=new LinearLayout(this);words.setOrientation(LinearLayout.VERTICAL);TextView name=text(TEMPLATE_NAMES[i],20,NAVY);name.setTypeface(Typeface.DEFAULT,Typeface.BOLD);words.addView(name);words.addView(text("Diseño profesional listo para personalizar",13,Color.GRAY));Button use=button("Usar este diseño");words.addView(use);card.addView(words,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,10,0,10);root.addView(card,cp);View.OnClickListener choose=v->{selectedTemplate=pick;prefs.edit().putInt("template_"+type,pick).apply();openDocument(type);};card.setOnClickListener(choose);use.setOnClickListener(choose);}
    }

    class TemplatePreview extends View{
        Paint p=new Paint(1);int style;String kind;TemplatePreview(Context c,int s,String k){super(c);style=s;kind=k;setLayerType(View.LAYER_TYPE_SOFTWARE,null);setElevation(4);}
        protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();p.setColor(Color.WHITE);c.drawRoundRect(4,4,w-4,h-4,12,12,p);int col=TEMPLATE_COLORS[style];p.setColor(col);if(style==1)c.drawRect(4,4,18,h-4,p);else if(style==2)c.drawRect(4,4,w-4,58,p);else if(style==3){c.drawCircle(w-18,18,55,p);c.drawRect(4,4,16,h-4,p);}else if(style==4)c.drawRoundRect(12,12,w-12,64,10,10,p);else if(style==5){c.drawRect(4,4,w-4,38,p);c.drawRect(4,h-26,w-4,h-4,p);}else c.drawRoundRect(4,4,w-4,68,12,12,p);p.setColor(style==1?col:Color.WHITE);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(11);c.drawText("SU NEGOCIO",style==1?28:18,30,p);p.setTextSize(7);c.drawText(kind.toUpperCase(Locale.getDefault()),style==1?28:18,48,p);p.setColor(Color.rgb(210,218,222));for(int y=88;y<h-34;y+=25){c.drawRoundRect(20,y,w-20,y+10,4,4,p);}p.setColor(col);c.drawRoundRect(w*.55f,h-46,w-20,h-28,5,5,p);}
    }

    void showProfile(){
        root=base(); scroll=new ScrollView(this); scroll.addView(root); setContentView(scroll);
        Button back=button("‹ Volver"); root.addView(back); back.setOnClickListener(v->showHome());
        TextView h=text("Identidad del negocio",26,NAVY); h.setTypeface(Typeface.DEFAULT,Typeface.BOLD); root.addView(h);
        TextView logoHelp=text("LOGO DEL NEGOCIO\nToca aquí para cargar PNG o JPG",15,Color.GRAY);logoHelp.setGravity(Gravity.CENTER);GradientDrawable upload=bordered(Color.WHITE,TEAL,24);upload.setStroke(3,TEAL,12,8);logoHelp.setBackground(upload);root.addView(logoHelp,new LinearLayout.LayoutParams(-1,120));
        logo=new ImageView(this); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); logo.setBackground(box(Color.WHITE,22)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,250);lp.setMargins(0,10,0,10);root.addView(logo,lp); loadLogo();
        View.OnClickListener picker=v->{ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,9); };logoHelp.setOnClickListener(picker);logo.setOnClickListener(picker);
        Button pick=button("Cargar o cambiar logo"); root.addView(pick); pick.setOnClickListener(picker);
        String[][] fs={{"business","Nombre del comercio"},{"address","Dirección"},{"phone","Teléfono"},{"email","Correo electrónico"},{"tax","RUC / identificación fiscal"},{"web","Sitio web o red social"}};
        for(String[] f:fs) root.addView(field(f[1],prefs.getString(f[0],""),f[0],false));
        Button save=button("Guardar información"); root.addView(save); save.setOnClickListener(v->{ Toast.makeText(this,"Información guardada",Toast.LENGTH_SHORT).show(); showHome(); });
    }

    EditText field(String hint,String value,String key,boolean multiline){
        EditText e=new EditText(this); e.setHint(hint); e.setText(value); e.setTextSize(textSize); e.setTextColor(textColor); e.setBackground(bordered(Color.WHITE,Color.rgb(165,183,190),18)); e.setPadding(20,16,20,16); e.setSingleLine(!multiline); if(multiline){e.setMinLines(4);e.setGravity(Gravity.TOP);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);}
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,7,0,7); e.setLayoutParams(p); e.setOnFocusChangeListener((v,has)->{if(has)focused=e;});
        if(key!=null) e.setOnEditorActionListener((v,a,event)->{ prefs.edit().putString(key,e.getText().toString()).apply(); return false;});
        if(key!=null) e.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){} public void onTextChanged(CharSequence s,int a,int b,int c){prefs.edit().putString(key,s.toString()).apply();}public void afterTextChanged(android.text.Editable x){}});
        return e;
    }

    void openDocument(String type){
        currentType=type;selectedTemplate=prefs.getInt("template_"+type,selectedTemplate); quantities.clear();prices.clear();amounts.clear();subtotalField=discountField=taxField=totalField=null; root=base(); scroll=new ScrollView(this); scroll.addView(root); setContentView(scroll);
        LinearLayout nav=new LinearLayout(this); Button back=button("‹ Inicio"); nav.addView(back,new LinearLayout.LayoutParams(0,-2,1)); Button designs=button("Diseños");nav.addView(designs,new LinearLayout.LayoutParams(0,-2,1)); Button profile=button("Negocio"); nav.addView(profile,new LinearLayout.LayoutParams(0,-2,1)); root.addView(nav); back.setOnClickListener(v->showHome());designs.setOnClickListener(v->showTemplates(type)); profile.setOnClickListener(v->showProfile());
        addBusinessHeader();
        TextView h=text(type.toUpperCase(Locale.getDefault()),24,NAVY); h.setTypeface(Typeface.DEFAULT,Typeface.BOLD); root.addView(h);
        String date=new SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(new Date());String hour=new SimpleDateFormat("hh:mm a",Locale.getDefault()).format(new Date()); int n=prefs.getInt("seq_"+type,1);
        TextView meta=text("N.º "+String.format(Locale.getDefault(),"%05d",n)+"     FECHA "+date+"     HORA "+hour,15,NAVY);meta.setBackground(box(Color.rgb(228,240,245),18));meta.setPadding(20,22,20,22); root.addView(meta);
        form=new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); root.addView(form);
        buildFields(type);
        addToolbar();
        Button pdf=button("Crear y guardar PDF"); root.addView(pdf); pdf.setOnClickListener(v->createPdf(false));
        Button share=button("Crear PDF y compartir"); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.setMargins(0,12,0,20);root.addView(share,sp);share.setOnClickListener(v->createPdf(true));
    }

    void addBusinessHeader(){
        int accent=TEMPLATE_COLORS[Math.max(0,Math.min(selectedTemplate,TEMPLATE_COLORS.length-1))];LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(22,22,22,22);card.setBackground(box(accent,28));
        ImageView mark=new ImageView(this);mark.setScaleType(ImageView.ScaleType.CENTER_INSIDE);Bitmap b=getLogo();if(b!=null)mark.setImageBitmap(b);else mark.setImageResource(android.R.drawable.ic_menu_gallery);card.addView(mark,new LinearLayout.LayoutParams(120,120));
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);TextView name=text(prefs.getString("business","NOMBRE DEL NEGOCIO"),22,Color.WHITE);name.setTypeface(Typeface.DEFAULT,Typeface.BOLD);info.addView(name);info.addView(text(prefs.getString("address","Configura los datos del negocio"),12,Color.WHITE));info.addView(text(prefs.getString("phone",""),12,Color.WHITE));card.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,14,0,20);root.addView(card,cp);
    }

    void addF(String hint,boolean multi){ form.addView(field(hint,"",null,multi)); }
    void buildFields(String t){
        if(t.equals("Recibo")){addF("Nombre del cliente",false);addF("Recibo por / motivo o servicio",false);addF("Concepto / trabajo realizado",true);EditText total=moneyField("TOTAL RECIBIDO B/.",true);total.setText("0.00");addF("Método de pago",false);addF("Recibido por / firma",false);}
        else if(t.equals("Factura")||t.equals("Cotización")){addF("Cliente",false);addF("Identificación / RUC",false);addF("Dirección y teléfono",false);for(int i=1;i<=3;i++)addItem(i);subtotalField=moneyField("Subtotal automático",false);discountField=moneyField("Descuento",true);taxField=moneyField("Impuesto %",true);totalField=moneyField("TOTAL",false);discountField.setText("0");taxField.setText("0");watchMath(discountField);watchMath(taxField);addF("Condiciones y observaciones",true);recalculate();}
        else if(t.equals("Membrete")){addF("Destinatario o asunto",false);addF("Contenido de la carta",true);addF("Nombre y cargo de quien firma",false);}
        else if(t.equals("Notas")){addF("Título de la nota",false);addF("Contenido",true);addF("Nombre o firma",false);}
        else {addF("Nombre completo",false);addF("Cargo o profesión",false);addF("Teléfono",false);addF("Correo electrónico",false);addF("Sitio web / red social",false);addF("Dirección",false);}
    }

    EditText moneyField(String hint,boolean editable){EditText e=field(hint,"",null,false);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);e.setEnabled(editable);if(!editable){e.setTextColor(NAVY);e.setTypeface(Typeface.DEFAULT,Typeface.BOLD);e.setBackground(box(Color.rgb(230,241,245),18));}form.addView(e);return e;}
    void addItem(int n){TextView label=text("PRODUCTO O SERVICIO "+n,13,NAVY);label.setTypeface(Typeface.DEFAULT,Typeface.BOLD);form.addView(label);addF("Descripción",false);EditText q=moneyField("Cantidad",true),p=moneyField("Precio unitario",true),a=moneyField("Importe automático",false);quantities.add(q);prices.add(p);amounts.add(a);watchMath(q);watchMath(p);}
    void watchMath(EditText e){e.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){recalculate();}public void afterTextChanged(android.text.Editable x){}});}
    double number(EditText e){try{return Double.parseDouble(e.getText().toString().replace(",","."));}catch(Exception x){return 0;}}
    void recalculate(){if(subtotalField==null)return;double sub=0;for(int i=0;i<quantities.size();i++){double value=number(quantities.get(i))*number(prices.get(i));sub+=value;amounts.get(i).setText(String.format(Locale.US,"%.2f",value));}double discount=number(discountField),taxPct=number(taxField),taxable=Math.max(0,sub-discount),total=taxable+(taxable*taxPct/100d);subtotalField.setText(String.format(Locale.US,"%.2f",sub));totalField.setText(String.format(Locale.US,"%.2f",total));}

    void addToolbar(){
        TextView lab=text("Herramientas de texto",14,NAVY); lab.setTypeface(Typeface.DEFAULT,Typeface.BOLD); root.addView(lab);
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER); root.addView(bar);
        String[] names={"A−","A+","B","Color"}; for(String s:names){Button b=button(s);bar.addView(b,new LinearLayout.LayoutParams(0,100,1));
            b.setOnClickListener(v->{ if(focused==null){Toast.makeText(this,"Toca primero un campo",Toast.LENGTH_SHORT).show();return;} String x=((Button)v).getText().toString(); if(x.equals("A−")){textSize=Math.max(10,focused.getTextSize()/getResources().getDisplayMetrics().scaledDensity-2);focused.setTextSize(textSize);} else if(x.equals("A+")){textSize=Math.min(34,focused.getTextSize()/getResources().getDisplayMetrics().scaledDensity+2);focused.setTextSize(textSize);} else if(x.equals("B")){fontStyle=fontStyle==Typeface.BOLD?Typeface.NORMAL:Typeface.BOLD;focused.setTypeface(Typeface.DEFAULT,fontStyle);} else chooseColor(); });}
    }
    void chooseColor(){ final int[] cs={Color.BLACK,Color.DKGRAY,Color.rgb(0,90,170),Color.rgb(0,130,95),Color.rgb(170,30,45)};String[] ns={"Negro","Gris","Azul","Verde","Rojo"};new AlertDialog.Builder(this).setTitle("Color del texto").setItems(ns,(d,w)->{textColor=cs[w];focused.setTextColor(textColor);}).show(); }

    void loadLogo(){ String s=prefs.getString("logo",""); if(!s.isEmpty()){try{logoUri=Uri.parse(s);logo.setImageURI(logoUri);}catch(Exception ignored){}} else logo.setImageResource(android.R.drawable.ic_menu_gallery); }
    @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(r==9&&c==RESULT_OK&&data!=null){logoUri=data.getData();try{getContentResolver().takePersistableUriPermission(logoUri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}prefs.edit().putString("logo",logoUri.toString()).apply();if(logo!=null)logo.setImageURI(logoUri);}}

    Bitmap getLogo(){ String s=prefs.getString("logo","");if(s.isEmpty())return null;try(InputStream in=getContentResolver().openInputStream(Uri.parse(s))){return BitmapFactory.decodeStream(in);}catch(Exception e){return null;} }
    String safe(String s){return s==null?"":s.trim();}
    void createPdf(boolean share){
        PdfDocument doc=new PdfDocument(); int W=595,H=842; PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(W,H,1).create());Canvas c=page.getCanvas();Paint p=new Paint(1);p.setColor(Color.WHITE);c.drawRect(0,0,W,H,p);
        int accent=TEMPLATE_COLORS[Math.max(0,Math.min(selectedTemplate,TEMPLATE_COLORS.length-1))];int y=42;if(selectedTemplate==2||selectedTemplate==5){p.setColor(accent);c.drawRect(0,0,W,105,p);}else if(selectedTemplate==1){p.setColor(accent);c.drawRect(0,0,18,H,p);}else if(selectedTemplate==3){p.setColor(accent);c.drawCircle(W-25,15,105,p);} Bitmap bm=getLogo();if(bm!=null){float sc=Math.min(110f/bm.getWidth(),70f/bm.getHeight());c.drawBitmap(bm,null,new RectF(38,y,38+bm.getWidth()*sc,y+bm.getHeight()*sc),p);}
        p.setColor((selectedTemplate==2||selectedTemplate==5)?Color.WHITE:NAVY);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));p.setTextSize(20);c.drawText(safe(prefs.getString("business","Mi negocio")),170,y+22,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(10);
        c.drawText(safe(prefs.getString("address","")),170,y+40,p);c.drawText(safe(prefs.getString("phone",""))+"  "+safe(prefs.getString("email","")),170,y+55,p);c.drawText(safe(prefs.getString("tax","")),170,y+70,p);
        y=132;p.setColor(accent);if(selectedTemplate==4)c.drawRoundRect(36,y-25,W-36,y+12,16,16,p);else c.drawRect(36,y-25,W-36,y+12,p);p.setColor(Color.WHITE);p.setTextSize(20);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));c.drawText(currentType.toUpperCase(Locale.getDefault()),48,y,p);
        p.setColor(Color.DKGRAY);p.setTextSize(11);p.setTypeface(Typeface.DEFAULT);String date=new SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(new Date());int n=prefs.getInt("seq_"+currentType,1);c.drawText("Fecha: "+date,38,y+34,p);c.drawText("N.º "+String.format(Locale.getDefault(),"%05d",n),450,y+34,p);y+=62;
        for(int i=0;i<form.getChildCount();i++){View child=form.getChildAt(i);if(!(child instanceof EditText))continue;EditText e=(EditText)child;String label=e.getHint()==null?"":e.getHint().toString();String val=e.getText().toString();p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));p.setColor(NAVY);p.setTextSize(10);c.drawText(label,38,y,p);y+=15;p.setTypeface(Typeface.DEFAULT);p.setColor(e.getCurrentTextColor());p.setTextSize(Math.min(16,e.getTextSize()/getResources().getDisplayMetrics().scaledDensity));y=drawWrapped(c,p,val,38,y,W-76);p.setColor(Color.LTGRAY);c.drawLine(38,y+3,W-38,y+3,p);y+=22;if(y>775)break;}
        p.setColor(Color.GRAY);p.setTextSize(8);c.drawText("Creado con Formatos Comerciales",38,815,p);doc.finishPage(page);
        String filename=currentType.replace(" ","-")+"-"+String.format(Locale.getDefault(),"%05d",n)+".pdf";try{Uri out=savePdf(doc,filename);prefs.edit().putInt("seq_"+currentType,n+1).apply();Toast.makeText(this,"Guardado en Descargas/Papeleria",Toast.LENGTH_LONG).show();if(share&&out!=null){Intent i=new Intent(Intent.ACTION_SEND);i.setType("application/pdf");i.putExtra(Intent.EXTRA_STREAM,out);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Compartir PDF"));}}catch(Exception e){Toast.makeText(this,"No se pudo crear: "+e.getMessage(),Toast.LENGTH_LONG).show();}finally{doc.close();}
    }
    int drawWrapped(Canvas c,Paint p,String s,float x,int y,float width){if(s.isEmpty()){return y+8;}String[] paras=s.split("\\n",-1);for(String para:paras){String line="";for(String word:para.split(" ")){String test=line.isEmpty()?word:line+" "+word;if(p.measureText(test)>width&&!line.isEmpty()){c.drawText(line,x,y,p);y+=18;line=word;}else line=test;}c.drawText(line,x,y,p);y+=18;}return y;}
    Uri savePdf(PdfDocument doc,String name)throws Exception{
        if(Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,"application/pdf");v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Papeleria");Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(u==null)throw new IOException("No se pudo abrir Descargas");try(OutputStream o=getContentResolver().openOutputStream(u)){doc.writeTo(o);}return u;}
        File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"Papeleria");if(!dir.exists()&&!dir.mkdirs())throw new IOException("No se pudo crear la carpeta");File f=new File(dir,name);try(OutputStream o=new FileOutputStream(f)){doc.writeTo(o);}return FileProvider.getUriForFile(this,getPackageName()+".files",f);
    }
}
