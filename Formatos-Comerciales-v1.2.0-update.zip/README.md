# Formatos Comerciales

Aplicación Android local para crear recibos, facturas, cotizaciones, membretes,
notas y tarjetas de presentación con identidad visual personalizada.

## Funciones de la v1

- Logo, nombre, dirección, teléfono, correo e identificación fiscal del negocio.
- Datos guardados localmente y reutilizables.
- Fecha actual y consecutivo independiente por tipo de documento.
- Editor con fuente, tamaño y color.
- Generación de PDF en `Descargas/Papeleria`.
- Compartir el PDF desde Android.
- Sin cuenta, servidor ni conexión a internet.

## Mejoras de la v1.1

- Formularios modernos inspirados en papelería comercial profesional.
- Membrete visual con logo y datos del negocio.
- Fecha, hora y consecutivo automáticos.
- Facturas y cotizaciones con tres productos o servicios.
- Cálculo automático de importe, subtotal, descuento, impuesto y total.

## Galería de formatos v1.2

- Seis diseños seleccionables por cada tipo de documento.
- Miniaturas visuales antes de abrir el editor.
- Botón para cambiar de diseño sin salir del documento.
- Composiciones corporativa, minimalista, ejecutiva, creativa, elegante y técnica.
- Selector moderno de logo con vista previa.
- El diseño escogido se aplica al formulario y al PDF.

## Compilación

Al subir a GitHub, el workflow **Construir APK Formatos Comerciales** genera el APK.
